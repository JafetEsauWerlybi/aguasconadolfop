export const roles = {
 admin : 'admin',
 regular: 'regular'
}