import React from 'react'

export default function Product() {
  return (
    <div>
      <h1>Product</h1>
    </div>
  )
}
